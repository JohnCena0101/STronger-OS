# STRANGE-TOOLS-

__Command__
```
git clone https://github.com/Z-BL4CX-H4T/STRANGE-TOOLS-.git
cd STRANGE-TOOLS-
python3 main.py
```
